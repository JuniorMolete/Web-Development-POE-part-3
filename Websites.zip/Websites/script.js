/* Paws Community Animal Shelter - Part 3 interactions */
(() => {
  'use strict';

  const shelterEmail = 'hello@pawscommunity.example';

  const serviceData = [
    { title: 'Adoption support', category: 'Animals', text: 'Understand an animal’s needs and make an informed, suitable adoption decision.', icon: '♥' },
    { title: 'Veterinary and rehabilitation care', category: 'Animals', text: 'Vaccinations, microchipping, sterilisation and behavioural support for animals in our care.', icon: '+' },
    { title: 'Foster care', category: 'Community', text: 'Provide a temporary home and help an animal adjust while a permanent home is found.', icon: '⌂' },
    { title: 'Volunteering and donations', category: 'Community', text: 'Contribute time, skills, supplies or financial support to strengthen the shelter’s work.', icon: '★' },
    { title: 'Education', category: 'Education', text: 'Learn about responsible pet ownership and healthier relationships between people and animals.', icon: 'i' }
  ];

  function setStatus(element, message, type = 'success') {
    if (!element) return;
    element.textContent = message;
    element.className = `form-status ${type}`;
    element.hidden = false;
  }

  function validateForm(form) {
    let valid = true;
    form.querySelectorAll('[data-error]').forEach((error) => { error.textContent = ''; });
    form.querySelectorAll('[required]').forEach((field) => {
      const error = form.querySelector(`[data-error-for="${field.id}"]`);
      let message = '';
      if (!field.value.trim()) message = 'Please complete this field.';
      else if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value.trim())) message = 'Enter a valid email address.';
      else if (field.type === 'tel' && !/^[+0-9 ()-]{7,20}$/.test(field.value.trim())) message = 'Enter a valid telephone number.';
      else if (field.name === 'message' && field.value.trim().length < 10) message = 'Please provide at least 10 characters.';
      if (message) {
        valid = false;
        if (error) error.textContent = message;
        field.setAttribute('aria-invalid', 'true');
      } else field.removeAttribute('aria-invalid');
    });
    return valid;
  }

  function setupForms() {
    document.querySelectorAll('form[data-ajax-form]').forEach((form) => {
      form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const status = form.querySelector('.form-status');
        if (!validateForm(form)) {
          setStatus(status, 'Please correct the highlighted fields before sending.', 'error');
          const firstInvalid = form.querySelector('[aria-invalid="true"]');
          if (firstInvalid) firstInvalid.focus();
          return;
        }
        const button = form.querySelector('button[type="submit"]');
        if (button) { button.disabled = true; button.textContent = 'Sending…'; }
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        // Try the declared endpoint first. Static hosting falls back to the local demo response.
        try {
          await fetch(form.action, { method: 'POST', body: formData, headers: { 'Accept': 'application/json' } });
        } catch (error) {
          await new Promise((resolve) => window.setTimeout(resolve, 650));
        }
        localStorage.setItem(`paws-${form.id || 'form'}-last-submission`, JSON.stringify({ ...data, submittedAt: new Date().toISOString() }));
        setStatus(status, form.id === 'enquiry-form'
          ? 'Thank you. Your enquiry has been received. We will respond with the relevant availability or cost information.'
          : 'Thank you. Your message has been prepared for the shelter team.', 'success');
        if (form.id === 'contact-form') {
          const subject = encodeURIComponent(`Website message: ${data.messageType || 'General enquiry'}`);
          const body = encodeURIComponent(`Name: ${data.name}\nEmail: ${data.email}\nPhone: ${data.phone || 'Not supplied'}\n\n${data.message}`);
          window.location.href = `mailto:${shelterEmail}?subject=${subject}&body=${body}`;
        }
        form.reset();
        if (button) { button.disabled = false; button.textContent = form.id === 'contact-form' ? 'Prepare email' : 'Send enquiry'; }
      });
    });
  }

  function renderServices(query = '', category = 'All') {
    const grid = document.querySelector('[data-service-grid]');
    if (!grid) return;
    const normalized = query.trim().toLowerCase();
    const matches = serviceData.filter((service) => {
      const inCategory = category === 'All' || service.category === category;
      const inSearch = !normalized || `${service.title} ${service.text} ${service.category}`.toLowerCase().includes(normalized);
      return inCategory && inSearch;
    });
    grid.innerHTML = matches.length ? matches.map((service) => `
      <article class="card service-card">
        <span class="service-icon" aria-hidden="true">${service.icon}</span>
        <p class="card-kicker">${service.category}</p>
        <h3>${service.title}</h3>
        <p>${service.text}</p>
        <a href="enquiry.html?interest=${encodeURIComponent(service.title)}">Ask about this service</a>
      </article>`).join('') : '<p class="empty-state">No services match that search. Try another keyword.</p>';
    const count = document.querySelector('[data-service-count]');
    if (count) count.textContent = `${matches.length} service${matches.length === 1 ? '' : 's'} shown`;
  }

  function setupServices() {
    const search = document.querySelector('[data-service-search]');
    const category = document.querySelector('[data-service-category]');
    if (!search || !category) return;
    const update = () => renderServices(search.value, category.value);
    search.addEventListener('input', update);
    category.addEventListener('change', update);
    renderServices();
  }

  function setupGallery() {
    const lightbox = document.querySelector('[data-lightbox]');
    if (!lightbox) return;
    const image = lightbox.querySelector('img');
    const caption = lightbox.querySelector('[data-lightbox-caption]');
    document.querySelectorAll('[data-gallery-image]').forEach((button) => {
      button.addEventListener('click', () => {
        image.src = button.dataset.src;
        image.alt = button.dataset.alt || '';
        caption.textContent = button.dataset.caption || '';
        lightbox.showModal();
      });
    });
    lightbox.addEventListener('click', (event) => {
      if (event.target === lightbox) lightbox.close();
    });
  }

  function setupEnquiryPreset() {
    const select = document.querySelector('#interest');
    const value = new URLSearchParams(window.location.search).get('interest');
    if (select && value) {
      const option = [...select.options].find((item) => item.text.toLowerCase() === value.toLowerCase());
      if (option) select.value = option.value;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    setupForms();
    setupServices();
    setupGallery();
    setupEnquiryPreset();
  });
})();
